RADIOBALKAN24 – KOMPLETAN ANDROID PROJEKT ZA IZGRADNJU APK-a

Ovaj paket sadrži Android modul app, AndroidManifest.xml, MainActivity.java,
RadioPlaybackService.java, Gradle konfiguraciju i GitHub Actions workflow.
Aplikacija otvara postojeću web-stranicu:
https://lighthearted-stardust-37d35c.netlify.app/

VAŽNO
- APK još nije potvrđeno izgrađen niti testiran na stvarnom telefonu.
- Ovaj projekt ne mijenja objavljenu Netlify stranicu.
- Reprodukciju u pozadini, obavijest playera, Bluetooth kontrole i streamove
  treba provjeriti nakon izgradnje i instalacije.
- Nemoj dodavati lozinke, tokene ili druge tajne podatke u repozitorij.

IZGRADNJA APK-a S MOBITELA PREKO GITHUBA
1. Otvori GitHub i napravi novi repozitorij. Ako želiš da kod ne bude javan,
   postavi repozitorij kao Private.
2. Raspakiraj ovaj ZIP. U korijenu repozitorija moraju biti mape app i
   .github te datoteke build.gradle, settings.gradle i gradle.properties.
   Nemoj učitavati samo ZIP kao jednu datoteku.
3. Učitaj cijeli sadržaj raspakiranog projekta u korijen repozitorija.
4. Otvori Actions i odaberi workflow “Build RadioBalkan24 Novi APK”.
5. Pritisni “Run workflow”. Pričekaj da završi.
6. Ako je rezultat zelen (Success), otvori taj run i u odjeljku Artifacts
   preuzmi “RadioBalkan24-Novi-debug-APK”.
7. Raspakiraj preuzeti artefakt i instaliraj app-debug.apk. Android može
   zatražiti dopuštenje za instaliranje aplikacija iz preglednika/datoteka.

AKO BUILD PADNE
Otvori neuspjeli run u Actions, otvori korak “Build debug APK” i pošalji
mi tekst ili snimku greške. Nemoj slati lozinke, tokene ni sigurnosne kodove.


ZAVRSNE ANDROID IZMJENE (07.11.2026.)
- Ugradena je ikona aplikacije iz zadnjeg dostupnog Balkan Radio logotipa.
- Play/Stop: ponovni dodir aktivne stanice zaustavlja Android reprodukciju; odabir druge stanice prebacuje reprodukciju.
- Vizualno stanje aktivne stanice, Play/Stop simbol i animirani ekvalizator sinkroniziraju se s Android reprodukcijom.
- Odrzava se heartbeat slusatelja dok Android reprodukcija radi.
- Referentna HTML datoteka nije mijenjana.
- Potrebno je provesti GitHub Actions izgradnju i test na stvarnom Android uredaju.
