package com.balkanradio.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.KeyEvent;
import android.content.Intent;
import android.net.Uri;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;

public class MainActivity extends Activity {
    private WebView webView;
    private ListenableFuture<MediaController> controllerFuture;
    private MediaController controller;
    private static final String SITE = "https://lighthearted-stardust-37d35c.netlify.app/";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF10131B);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false); s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true); s.setSupportZoom(false);
        webView.addJavascriptInterface(new RadioBridge(), "RadioBalkanNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Native playback bridge: keep the website UI in sync with Android Media3.
                String js = """
                    (function(){
                      if(window.__rbNativePatchInstalled) return;
                      window.__rbNativePatchInstalled=true;
                      window.__rbNativePlaying=false;
                      window.__rbNativeStationId='';
                      var heartbeatTimer=null;
                      var SUPABASE_URL='https://qfppbhyibwlotivqnzml.supabase.co';
                      var SUPABASE_KEY='sb_publishable_xa3UA3cVji4Dn-Az2z0_Lg_gN3vCn0j';
                      function paint(on,id){
                        try{
                          window.__rbNativePlaying=!!on;
                          window.__rbNativeStationId=on?String(id||''):'';
                          document.querySelectorAll('[data-station-card]').forEach(function(card){
                            var active=!!on && card.getAttribute('data-station-card')===String(id||'');
                            card.classList.toggle('is-playing',active);
                            var button=card.querySelector('[data-play]');
                            if(button){
                              button.classList.toggle('is-playing',active);
                              button.title=active?'Zaustavi':'Slušaj';
                              var symbol=button.querySelector('.play-symbol');
                              if(symbol) symbol.textContent=active?'Ⅱ':'▶';
                            }
                            var count=card.querySelector('.listener-count');
                            if(count && active){
                              count.hidden=false;
                              var number=count.querySelector('.listener-number');
                              if(number && Number(number.textContent)<1) number.textContent='1';
                            }
                          });
                          var player=document.getElementById('playerbar');
                          if(player) player.classList.toggle('playing',!!on);
                          var state=document.getElementById('nowstate');
                          if(state) state.textContent=on?'Svira uživo':'Zaustavljeno';
                          var total=document.getElementById('total-listener-number');
                          if(total && on && Number(total.textContent)<1) total.textContent='1';
                        }catch(e){}
                      }
                      function sendHeartbeat(){
                        if(!window.__rbNativePlaying || !window.__rbNativeStationId) return;
                        try{
                          var session=localStorage.getItem('balkanRadioListenerSession');
                          if(!session){session=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():('s'+Date.now().toString(36)+Math.random().toString(36).slice(2));localStorage.setItem('balkanRadioListenerSession',session);}
                          fetch(SUPABASE_URL+'/rest/v1/radio_listeners?on_conflict=station_id,session_id',{
                            method:'POST',headers:{'Content-Type':'application/json','apikey':SUPABASE_KEY,'Authorization':'Bearer '+SUPABASE_KEY,'Prefer':'resolution=merge-duplicates,return=minimal'},
                            body:JSON.stringify({station_id:String(window.__rbNativeStationId),session_id:session,last_seen:new Date().toISOString()}),cache:'no-store'
                          }).catch(function(){});
                        }catch(e){}
                      }
                      function startHeartbeat(){if(heartbeatTimer)clearInterval(heartbeatTimer);sendHeartbeat();heartbeatTimer=setInterval(sendHeartbeat,30000);}
                      function stopHeartbeat(){if(heartbeatTimer){clearInterval(heartbeatTimer);heartbeatTimer=null;}}
                      function patch(){
                        if(typeof window.playStation==='function'&&!window.__rbPlayWrapped){
                          var originalPlay=window.playStation;
                          window.playStation=async function(id){
                            var wanted=String(id||'');
                            if(window.__rbNativePlaying && window.__rbNativeStationId===wanted){
                              if(typeof window.stopPlayback==='function') window.stopPlayback();
                              else {try{RadioBalkanNative.stop();}catch(e){} paint(false,'');stopHeartbeat();}
                              return;
                            }
                            if(window.__rbNativePlaying){try{RadioBalkanNative.stop();}catch(e){}paint(false,'');stopHeartbeat();}
                            var result=await originalPlay.apply(this,arguments);
                            setTimeout(function(){
                              try{
                                var audio=document.querySelector('audio');
                                var name=document.getElementById('nowname');
                                if(audio && audio.currentSrc){
                                  RadioBalkanNative.play(audio.currentSrc,(name&&name.textContent)||'RadioBalkan24');
                                  audio.pause();
                                  paint(true,wanted);
                                  startHeartbeat();
                                  if(typeof window.refreshListenerCounts==='function'){
                                    Promise.resolve(window.refreshListenerCounts()).then(function(){paint(true,wanted);}).catch(function(){});
                                  }
                                }
                              }catch(e){}
                            },700);
                            return result;
                          };
                          window.__rbPlayWrapped=true;
                        }
                        if(typeof window.stopPlayback==='function'&&!window.__rbStopWrapped){
                          var originalStop=window.stopPlayback;
                          window.stopPlayback=function(){
                            stopHeartbeat();
                            try{RadioBalkanNative.stop();}catch(e){}
                            paint(false,'');
                            return originalStop.apply(this,arguments);
                          };
                          window.__rbStopWrapped=true;
                        }
                      }
                      patch();
                      setInterval(patch,400);
                    })();
                    """;
                view.evaluateJavascript(js, null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
                    Uri u = Uri.parse(url);
                    if (SITE.startsWith(u.getScheme()+"://"+u.getHost())) return false;
                    // Keep ordinary navigation in the app; external intent links are left to WebView.
                }
                return false;
            }
        });
        setContentView(webView);
        SessionToken token = new SessionToken(this, new android.content.ComponentName(this, RadioPlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> { try { controller = controllerFuture.get(); } catch (Exception ignored) {} }, ContextCompat.getMainExecutor(this));
        webView.loadUrl(SITE);
    }

    private class RadioBridge {
        @JavascriptInterface public void play(String url, String title) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(() -> {
                Intent i = new Intent(MainActivity.this, RadioPlaybackService.class);
                i.setAction(RadioPlaybackService.ACTION_PLAY); i.putExtra(RadioPlaybackService.EXTRA_URL, url);
                i.putExtra(RadioPlaybackService.EXTRA_TITLE, title == null || title.trim().isEmpty() ? "Radio uživo" : title);
                ContextCompat.startForegroundService(MainActivity.this, i);
            });
        }
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> { Intent i = new Intent(MainActivity.this, RadioPlaybackService.class); i.setAction(RadioPlaybackService.ACTION_STOP); startService(i); });
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) { webView.goBack(); return true; }
        return super.onKeyDown(keyCode, event);
    }
    @Override protected void onDestroy() {
        if (controllerFuture != null) MediaController.releaseFuture(controllerFuture);
        if (webView != null) webView.destroy(); super.onDestroy();
    }
}
