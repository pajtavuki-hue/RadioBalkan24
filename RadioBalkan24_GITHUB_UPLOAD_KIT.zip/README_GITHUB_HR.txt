RADIOBALKAN24 – GITHUB UPLOAD KIT

Ovaj paket je pripremljen za postojeći GitHub Actions način rada koji traži ZIP naziva:
RadioBalkan24_ANDROID_ISPRAVLJEN.zip

KAKO KORISTITI
1. Raspakiraj ovaj vanjski ZIP na telefonu ili računalu.
2. U GitHub repozitorij učitaj sadržaj raspakirane mape, tako da u korijenu repozitorija budu:
   - RadioBalkan24_ANDROID_ISPRAVLJEN.zip
   - .github/workflows/build-apk.yml
   - README_GITHUB_HR.txt (upute; nije potreban za build)
3. Nemoj raspakirati unutarnji RadioBalkan24_ANDROID_ISPRAVLJEN.zip. GitHub Actions će ga sam raspakirati u mapu project i izgraditi APK.
4. Otvori Actions i pokreni workflow “Build RadioBalkan24 APK”.
5. Nakon uspješnog zelenog rezultata preuzmi artifact “RadioBalkan24-APK”.

Android projekt unutar ZIP-a ostavljen je kakav je bio u dostavljenoj projektnoj arhivi; ovaj paket usklađuje samo način predaje ZIP-a i workflow s nazivom datoteke koju GitHub traži.
